def main():
    print("This is a test for a command line poetry package")
